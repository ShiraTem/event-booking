from fastapi import FastAPI, HTTPException, Depends
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.requests import Request
from pydantic import BaseModel
from sqlalchemy import create_engine, Column, Integer, String, ForeignKey
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session

# Настройка БД SQLite
SQLALCHEMY_DATABASE_URL = "sqlite:///./restaurant.db"
engine = create_engine(SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Модели базы данных
class User(Base):
    __tablename__ = "users"
    phone = Column(String, primary_key=True, index=True)
    name = Column(String)

class Booking(Base):
    __tablename__ = "bookings"
    seat_number = Column(Integer, primary_key=True, index=True)
    phone = Column(String, ForeignKey("users.phone"))

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Restaurant Booking")
templates = Jinja2Templates(directory="templates")

# Pydantic схемы
class UserRegister(BaseModel):
    phone: str
    name: str

class BookingCreate(BaseModel):
    phone: str
    seat_number: int

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.get("/", response_class=HTMLResponse)
def read_root(request: Request):
    return templates.TemplateResponse(request, "index.html")

@app.post("/api/register")
def register_user(user: UserRegister, db: Session = Depends(get_db)):
    db_user = db.query(User).filter(User.phone == user.phone).first()
    if db_user:
        db_user.name = user.name
    else:
        db_user = User(phone=user.phone, name=user.name)
        db.add(db_user)
    db.commit()
    return {"message": "Успешно зарегистрировано", "phone": user.phone, "name": user.name}

@app.get("/api/seats")
def get_seats(db: Session = Depends(get_db)):
    all_seats = {i: None for i in range(1, 11)}
    bookings = db.query(Booking).all()
    
    for b in bookings:
        user = db.query(User).filter(User.phone == b.phone).first()
        all_seats[b.seat_number] = {
            "phone": b.phone,
            "name": user.name if user else "Гость"
        }

    result = [{"seat_number": seat, "booked_by": info} for seat, info in all_seats.items()]
    return result

@app.post("/api/book")
def book_seat(data: BookingCreate, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.phone == data.phone).first()
    if not user:
        raise HTTPException(status_code=400, detail="Сначала зарегистрируйтесь по номеру телефона!")
    
    if not (1 <= data.seat_number <= 10):
        raise HTTPException(status_code=400, detail="Неверный номер места (доступно от 1 до 10).")
    
    existing = db.query(Booking).filter(Booking.seat_number == data.seat_number).first()
    if existing:
        if existing.phone == data.phone:
            raise HTTPException(status_code=400, detail="Это место уже забронировано вами.")
        raise HTTPException(status_code=400, detail="Место уже занято другим клиентом.")
    
    user_booking = db.query(Booking).filter(Booking.phone == data.phone).first()
    if user_booking:
        raise HTTPException(status_code=400, detail=f"У вас уже забронировано место №{user_booking.seat_number}.")

    new_booking = Booking(seat_number=data.seat_number, phone=data.phone)
    db.add(new_booking)
    db.commit()
    return {"message": f"Место №{data.seat_number} успешно забронировано!"}

@app.delete("/api/book/{seat_number}")
def cancel_booking(seat_number: int, phone: str, db: Session = Depends(get_db)):
    booking = db.query(Booking).filter(Booking.seat_number == seat_number).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Бронь не найдена.")
    
    if booking.phone != phone:
        raise HTTPException(status_code=403, detail="Вы можете отменять только свои бронирования.")
    
    db.delete(booking)
    db.commit()
    return {"message": "Бронь успешно отменена."}